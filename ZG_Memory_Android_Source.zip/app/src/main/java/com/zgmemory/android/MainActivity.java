package com.zgmemory.android;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.media.MediaPlayer;
import android.content.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(12, 10, 19);
    private final int PANEL = Color.rgb(29, 23, 42);
    private final int PANEL2 = Color.rgb(39, 29, 54);
    private final int PURPLE = Color.rgb(192, 112, 255);
    private final int WHITE = Color.WHITE;
    private final int MUTED = Color.rgb(183, 172, 199);
    private final int GOLD = Color.rgb(255, 184, 38);

    private EditText searchBox;
    private LinearLayout listLayout, libraryRoot, miniPlayer;
    private TextView status, miniTitle, miniArtist, miniPlay;
    private ImageView miniCover;
    private MediaPlayer player;
    private ArrayList<JSONObject> songs = new ArrayList<>();
    private JSONObject currentSong;
    private String supabaseUrl = "", publishableKey = "";
    private final String PREFS = "zg_config";
    private boolean isFullScreen = false;
    private int currentTab = 0;
    private FrameLayout mainFrame;
    private LinearLayout mainColumn;
    private String currentQuery = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(0);
        android.content.SharedPreferences p = getSharedPreferences(PREFS, 0);
        supabaseUrl = p.getString("url", "");
        publishableKey = p.getString("key", "");
        buildLibrary();
        if (supabaseUrl.isEmpty() || publishableKey.isEmpty()) showConfig();
        else loadSongs("");
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable shape(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private GradientDrawable gradient(int top, int bottom, float radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{top, bottom});
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private TextView pillButton(String label, int bg, int fg) {
        TextView t = text(label, 14, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(13), dp(10), dp(13), dp(10));
        t.setBackground(shape(bg, 22));
        return t;
    }

    private void buildLibrary() {
        isFullScreen = false;
        mainFrame = new FrameLayout(this);
        mainFrame.setBackgroundColor(BG);
        mainColumn = column();
        mainColumn.setPadding(dp(16), dp(12), dp(16), 0);
        mainFrame.addView(mainColumn, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout header = row();
        LinearLayout brand = column();
        TextView title = text("ZG MEMORY", 25, WHITE, true);
        title.setLetterSpacing(.02f);
        brand.addView(title);
        TextView subtitle = text("Zubeen Garg  •  Music Library", 13, MUTED, false);
        brand.addView(subtitle);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView settings = text("⚙", 25, PURPLE, false);
        settings.setGravity(Gravity.CENTER);
        settings.setPadding(dp(12), dp(4), dp(4), dp(4));
        settings.setOnClickListener(v -> showConfig());
        header.addView(settings);
        mainColumn.addView(header);

        HorizontalScrollView tabsScroll = new HorizontalScrollView(this);
        tabsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs = row();
        tabs.setPadding(0, dp(14), 0, dp(12));
        String[] tabNames = {"Tracks", "Albums", "Artists", "Favourites", "Playlists"};
        for (int i=0;i<tabNames.length;i++) {
            final int ix = i;
            TextView tab = text(tabNames[i], 13, i==currentTab ? WHITE : MUTED, i==currentTab);
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(dp(16), dp(10), dp(16), dp(10));
            tab.setBackground(i==currentTab ? gradient(Color.rgb(143,72,225), Color.rgb(196,83,238), 25) : shape(BG,25));
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
            tp.setMargins(0, 0, dp(6), 0);
            tabs.addView(tab,tp);
            tab.setOnClickListener(v -> {
                currentTab = ix;
                if (ix == 0) loadSongs(currentQuery);
                else showTabMessage(tabNames[ix]);
                buildLibraryChromeOnly();
            });
        }
        tabsScroll.addView(tabs);
        mainColumn.addView(tabsScroll);

        LinearLayout searchRow = row();
        searchRow.setBackground(shape(PANEL, 26));
        searchRow.setPadding(dp(13), 0, dp(12), 0);
        TextView searchIcon = text("⌕", 25, MUTED, false);
        searchRow.addView(searchIcon);
        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setTextSize(14);
        searchBox.setTextColor(WHITE);
        searchBox.setHintTextColor(MUTED);
        searchBox.setHint("Search songs, albums, year...");
        searchBox.setBackgroundColor(Color.TRANSPARENT);
        searchBox.setPadding(dp(8), dp(12), dp(4), dp(12));
        searchBox.setText(currentQuery);
        searchRow.addView(searchBox, new LinearLayout.LayoutParams(0, -2, 1));
        TextView searchBtn = text("⌕", 23, PURPLE, true);
        searchBtn.setGravity(Gravity.CENTER);
        searchBtn.setPadding(dp(8), 0, dp(4), 0);
        searchBtn.setOnClickListener(v -> {
            currentQuery = searchBox.getText().toString().trim();
            ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(searchBox.getWindowToken(),0);
            loadSongs(currentQuery);
        });
        searchRow.addView(searchBtn);
        LinearLayout.LayoutParams srp = new LinearLayout.LayoutParams(-1, -2);
        srp.setMargins(0, 0, 0, dp(10));
        mainColumn.addView(searchRow, srp);

        status = text("Loading your collection…", 13, MUTED, false);
        status.setPadding(dp(3), dp(2), 0, dp(8));
        mainColumn.addView(status);

        FrameLayout listFrame = new FrameLayout(this);
        LinearLayout.LayoutParams lfp = new LinearLayout.LayoutParams(-1, 0, 1);
        listLayout = column();
        listLayout.setPadding(0, 0, dp(22), dp(10));
        ScrollView listScroll = new ScrollView(this);
        listScroll.setFillViewport(false);
        listScroll.setVerticalScrollBarEnabled(false);
        listScroll.addView(listLayout);
        listFrame.addView(listScroll, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout alphabet = column();
        alphabet.setGravity(Gravity.CENTER);
        String letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ#";
        for (int i=0;i<letters.length();i++) {
            final String letter = String.valueOf(letters.charAt(i));
            TextView lt = text(letter, 9, MUTED, false);
            lt.setGravity(Gravity.CENTER);
            lt.setMinWidth(dp(18));
            lt.setPadding(0, dp(1), 0, dp(1));
            lt.setOnClickListener(v -> jumpToLetter(letter));
            alphabet.addView(lt);
        }
        FrameLayout.LayoutParams alp = new FrameLayout.LayoutParams(dp(22), -1, Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        listFrame.addView(alphabet, alp);
        mainColumn.addView(listFrame, lfp);

        miniPlayer = row();
        miniPlayer.setPadding(dp(10), dp(8), dp(10), dp(8));
        miniPlayer.setBackground(gradient(Color.rgb(255,176,27), Color.rgb(235,130,30), 30));
        miniCover = new ImageView(this);
        miniCover.setImageDrawable(defaultCover());
        miniCover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        miniPlayer.addView(miniCover, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout meta = column();
        meta.setPadding(dp(9), 0, dp(6), 0);
        miniTitle = text("Choose a song", 13, Color.WHITE, true);
        miniArtist = text("Zubeen Garg", 11, Color.WHITE, false);
        meta.addView(miniTitle);
        meta.addView(miniArtist);
        miniPlayer.addView(meta, new LinearLayout.LayoutParams(0, -2, 1));
        TextView previous = text("|◀", 17, Color.WHITE, true);
        previous.setPadding(dp(5), dp(8), dp(5), dp(8));
        previous.setOnClickListener(v -> playAt(Math.max(0, indexOfCurrent()-1)));
        miniPlayer.addView(previous);
        miniPlay = text("▶", 18, Color.WHITE, true);
        miniPlay.setGravity(Gravity.CENTER);
        miniPlay.setPadding(dp(9), dp(8), dp(9), dp(8));
        miniPlay.setOnClickListener(v -> togglePlayback());
        miniPlayer.addView(miniPlay);
        TextView next = text("▶|", 17, Color.WHITE, true);
        next.setPadding(dp(5), dp(8), dp(5), dp(8));
        next.setOnClickListener(v -> playAt(Math.min(songs.size()-1, indexOfCurrent()+1)));
        miniPlayer.addView(next);
        miniPlayer.setOnClickListener(v -> showFullScreen());
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
        mp.setMargins(0, dp(8), 0, dp(8));
        mainColumn.addView(miniPlayer, mp);

        LinearLayout bottomNav = row();
        bottomNav.setGravity(Gravity.CENTER);
        String[] nav = {"⌂\nHome", "▤\nAlbums", "♡\nFavourites", "♫\nLibrary"};
        for (int i=0;i<nav.length;i++) {
            final int ix=i;
            TextView item = text(nav[i], 11, i==0?PURPLE:MUTED, i==0);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(10), dp(2), dp(10), dp(7));
            bottomNav.addView(item, new LinearLayout.LayoutParams(0, -2, 1));
            item.setOnClickListener(v -> {
                if(ix==0) { currentTab=0; loadSongs(currentQuery); }
                else if(ix==1) showTabMessage("Albums");
                else if(ix==2) showTabMessage("Favourites");
                else showTabMessage("Library");
            });
        }
        mainColumn.addView(bottomNav);
        setContentView(mainFrame);
        if (!songs.isEmpty()) {
            listLayout.removeAllViews();
            for (JSONObject s : songs) addRow(s);
            status.setText(songs.size() + " Zubeen Garg songs");
        }
    }

    private void buildLibraryChromeOnly() {
        // Keep current library intact; tab selection is reflected by reloading the library on Tracks.
        if (currentTab == 0) {
            status.setText(songs.size() + " Zubeen Garg songs");
        }
    }

    private void showTabMessage(String tab) {
        if (status != null) status.setText(tab + " view is planned; all songs remain available in Tracks.");
        if (currentTab != 0) {
            currentTab = 0;
            if (status != null) status.setText("Choose Tracks to browse all songs.");
        }
    }

    private void addRow(JSONObject s) {
        LinearLayout item = row();
        item.setTag(s.optString("title", ""));
        item.setPadding(dp(5), dp(8), dp(4), dp(8));
        item.setBackgroundColor(Color.TRANSPARENT);
        ImageView cover = new ImageView(this);
        cover.setImageDrawable(defaultCover());
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        item.addView(cover, new LinearLayout.LayoutParams(dp(54), dp(54)));
        loadCoverInto(cover, s);
        LinearLayout info = column();
        info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(dp(10), 0, dp(4), 0);
        TextView title = text(s.optString("title","Untitled"), 14, WHITE, true);
        title.setMaxLines(1);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        info.addView(title);
        String album = s.optString("album","Album unknown");
        String year = s.optString("year","");
        TextView artist = text("Zubeen Garg", 12, MUTED, false);
        info.addView(artist);
        TextView details = text(album + (year.isEmpty() ? "" : " · " + year), 11, MUTED, false);
        details.setMaxLines(1);
        details.setEllipsize(android.text.TextUtils.TruncateAt.END);
        info.addView(details);
        item.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        TextView more = text("⋮", 23, MUTED, false);
        more.setGravity(Gravity.CENTER);
        more.setPadding(dp(8), 0, dp(4), 0);
        more.setOnClickListener(v -> new AlertDialog.Builder(this).setItems(new String[]{"Play now","Open full-screen player","Add to favourites"},(d,w)->{if(w==0)playSong(s);else if(w==1){playSong(s);showFullScreen();}else Toast.makeText(this,"Favourites can be added in a later update.",Toast.LENGTH_SHORT).show();}).show());
        item.addView(more);
        item.setOnClickListener(v -> playSong(s));
        listLayout.addView(item);
        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(47,38,58));
        LinearLayout.LayoutParams dpv = new LinearLayout.LayoutParams(-1, dp(1));
        dpv.setMargins(dp(66), dp(1), dp(8), 0);
        listLayout.addView(divider, dpv);
    }

    private void jumpToLetter(String letter) {
        if (listLayout == null) return;
        for (int i=0;i<listLayout.getChildCount();i++) {
            View v = listLayout.getChildAt(i);
            if (v instanceof LinearLayout && v.getTag() != null && v.getTag().toString().toUpperCase(Locale.ROOT).startsWith(letter)) {
                v.requestFocus();
                break;
            }
        }
    }

    private Drawable defaultCover() {
        GradientDrawable gd = gradient(Color.rgb(76,39,108), Color.rgb(23,17,34), 14);
        return gd;
    }

    private void loadCoverInto(ImageView target, JSONObject song) {
        String url = song.optString("cover_url","");
        if (url.isEmpty() || url.equals("null")) {
            String path = song.optString("cover_path","");
            if (!path.isEmpty() && !path.equals("null") && !supabaseUrl.isEmpty()) {
                try { url = supabaseUrl + "/storage/v1/object/public/music-covers/" + pathEncode(path); }
                catch(Exception ignored) {}
            }
        }
        if (url.isEmpty() || url.equals("null")) return;
        final String finalUrl = url;
        target.setTag(finalUrl);
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection)new URL(finalUrl).openConnection();
                c.setConnectTimeout(8000); c.setReadTimeout(10000);
                InputStream in = c.getInputStream();
                Bitmap bmp = BitmapFactory.decodeStream(in);
                in.close(); c.disconnect();
                if (bmp != null) runOnUiThread(() -> {
                    if (finalUrl.equals(target.getTag())) target.setImageBitmap(bmp);
                });
            } catch(Exception ignored) {}
        }).start();
    }

    private void loadSongs(String q) {
        currentQuery = q == null ? "" : q;
        if (supabaseUrl.isEmpty() || publishableKey.isEmpty()) {
            if (status != null) status.setText("Add Supabase settings first.");
            return;
        }
        if (status != null) status.setText("Loading your collection…");
        if (listLayout != null) listLayout.removeAllViews();
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                String url = supabaseUrl + "/rest/v1/songs?select=*&order=sort_order.asc";
                c = (HttpURLConnection)new URL(url).openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(15000);
                c.setReadTimeout(20000);
                c.setRequestProperty("apikey", publishableKey);
                c.setRequestProperty("Authorization", "Bearer " + publishableKey);
                int code = c.getResponseCode();
                InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                String body = readAll(in);
                if (in != null) in.close();
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + body);
                JSONArray a = new JSONArray(body);
                ArrayList<JSONObject> got = new ArrayList<>();
                String needle = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
                for (int i=0;i<a.length();i++) {
                    JSONObject s = a.getJSONObject(i);
                    if (!s.optString("artist","").toLowerCase(Locale.ROOT).contains("zubeen garg")) continue;
                    if (!needle.isEmpty()) {
                        String hay = (s.optString("title","")+" "+s.optString("album","")+" "+s.optString("year","")+" "+s.optString("artist","")).toLowerCase(Locale.ROOT);
                        if (!hay.contains(needle)) continue;
                    }
                    got.add(s);
                }
                runOnUiThread(() -> {
                    songs = got;
                    if (status != null) status.setText(got.size() + " Zubeen Garg songs");
                    if (listLayout != null) {
                        listLayout.removeAllViews();
                        if (got.isEmpty()) addMessage("No songs found. Check table permissions and artist values.");
                        for (JSONObject s : got) addRow(s);
                    }
                });
            } catch(Exception e) {
                String m = e.getMessage() == null ? "Unknown error" : e.getMessage();
                runOnUiThread(() -> { if(status!=null) status.setText("Load failed: " + m); });
            } finally { if(c!=null) c.disconnect(); }
        }).start();
    }

    private void addMessage(String message) {
        TextView t = text(message, 13, MUTED, false);
        t.setPadding(dp(8), dp(18), dp(8), dp(18));
        listLayout.addView(t);
    }

    private void showConfig() {
        LinearLayout form = column();
        form.setPadding(dp(20), dp(8), dp(20), 0);
        EditText u = new EditText(this);
        u.setSingleLine(true); u.setHint("Supabase Project URL"); u.setText(supabaseUrl);
        EditText k = new EditText(this);
        k.setSingleLine(true); k.setHint("Publishable / anon key ONLY"); k.setText(publishableKey);
        form.addView(u); form.addView(k);
        new AlertDialog.Builder(this).setTitle("Connect ZG Memory")
            .setMessage("Never enter service_role or secret keys. Use the project URL and publishable/anon key.")
            .setView(form)
            .setPositiveButton("Save & Connect",(d,w)->{
                supabaseUrl=u.getText().toString().trim().replaceAll("/+$","");
                publishableKey=k.getText().toString().trim();
                getSharedPreferences(PREFS,0).edit().putString("url",supabaseUrl).putString("key",publishableKey).apply();
                loadSongs("");
            }).setNegativeButton("Cancel",null).show();
    }

    private String audioUrl(JSONObject s) throws Exception {
        String p=s.optString("audio_path","");
        if(p.startsWith("http://")||p.startsWith("https://")) return p;
        if(p.isEmpty()||p.equals("null")) throw new Exception("Missing audio_path");
        return supabaseUrl+"/storage/v1/object/public/music-audio/"+pathEncode(p);
    }

    private void playSong(JSONObject s) {
        try {
            if(player!=null){player.release();player=null;}
            currentSong=s;
            if(miniTitle!=null) miniTitle.setText(s.optString("title","Untitled"));
            if(miniArtist!=null) miniArtist.setText("Zubeen Garg");
            if(miniCover!=null) loadCoverInto(miniCover,s);
            if(miniPlay!=null) miniPlay.setText("Ⅱ");
            String u=audioUrl(s);
            player=new MediaPlayer();
            player.setDataSource(u);
            player.setOnPreparedListener(mp->{
                mp.start();
                if(miniPlay!=null) miniPlay.setText("Ⅱ");
            });
            player.setOnCompletionListener(mp->{if(miniPlay!=null)miniPlay.setText("▶");});
            player.setOnErrorListener((mp,w,e)->{
                Toast.makeText(this,"Playback error. Check audio_path and music-audio bucket.",Toast.LENGTH_LONG).show();
                if(miniPlay!=null)miniPlay.setText("▶");
                return true;
            });
            player.prepareAsync();
            if(isFullScreen) showFullScreen();
        } catch(Exception e) {
            Toast.makeText(this,"Cannot play: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    private void togglePlayback() {
        if(player==null){ if(!songs.isEmpty())playSong(songs.get(0)); return; }
        try {
            if(player.isPlaying()){player.pause();if(miniPlay!=null)miniPlay.setText("▶");}
            else {player.start();if(miniPlay!=null)miniPlay.setText("Ⅱ");}
        } catch(Exception ignored) {}
    }

    private int indexOfCurrent() {
        if(currentSong==null)return 0;
        for(int i=0;i<songs.size();i++)if(songs.get(i).optString("id","").equals(currentSong.optString("id","")))return i;
        return 0;
    }

    private void playAt(int i) { if(i>=0&&i<songs.size())playSong(songs.get(i)); }

    private void showFullScreen() {
        if(currentSong==null) {
            if(!songs.isEmpty()) { playSong(songs.get(0)); return; }
            Toast.makeText(this,"Choose a song first.",Toast.LENGTH_SHORT).show(); return;
        }
        isFullScreen=true;
        int[] colors = {Color.rgb(255,183,104), Color.rgb(245,90,139), Color.rgb(111,36,115)};
        LinearLayout root=column();
        root.setPadding(dp(20),dp(10),dp(20),dp(20));
        root.setBackground(gradient(colors[0],colors[2],0));
        // Overlay a soft gradient using a background drawable with three color stops.
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,colors);
        root.setBackground(bg);

        LinearLayout top=row();
        TextView down=text("⌄",32,WHITE,false);
        down.setPadding(dp(4),dp(4),dp(12),dp(4));
        down.setOnClickListener(v->buildLibrary());
        top.addView(down);
        LinearLayout topMeta=column(); topMeta.setGravity(Gravity.CENTER);
        TextView playingFrom=text("PLAYING FROM",10,Color.rgb(255,236,238),true);
        TextView album=text(currentSong.optString("album","ZG Memory"),13,WHITE,true);
        topMeta.addView(playingFrom); topMeta.addView(album);
        top.addView(topMeta,new LinearLayout.LayoutParams(0,-2,1));
        TextView more=text("⋮",26,WHITE,true); more.setPadding(dp(10),dp(4),dp(4),dp(4));
        more.setOnClickListener(v->new AlertDialog.Builder(this).setItems(new String[]{"Supabase Settings","Back to library"},(d,w)->{if(w==0)showConfig();else buildLibrary();}).show());
        top.addView(more);
        root.addView(top);

        ImageView cover=new ImageView(this);
        cover.setImageDrawable(defaultCover());
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,0,4f);
        cp.setMargins(dp(10),dp(22),dp(10),dp(16));
        root.addView(cover,cp);
        loadCoverInto(cover,currentSong);
        cover.setBackground(shape(Color.BLACK,24));
        cover.setClipToOutline(true);

        TextView title=text(currentSong.optString("title","Untitled"),24,WHITE,true);
        title.setGravity(Gravity.CENTER);
        title.setMaxLines(2);
        TextView artist=text("Zubeen Garg",16,WHITE,false); artist.setGravity(Gravity.CENTER);
        TextView albumName=text(currentSong.optString("album",""),13,Color.rgb(255,235,238),false); albumName.setGravity(Gravity.CENTER);
        root.addView(title); root.addView(artist); root.addView(albumName);

        LinearLayout actions=row(); actions.setGravity(Gravity.CENTER);
        TextView heart=text("♡",29,WHITE,false); heart.setGravity(Gravity.CENTER); actions.addView(heart,new LinearLayout.LayoutParams(0,dp(50),1));
        TextView add=text("+",32,WHITE,false); add.setGravity(Gravity.CENTER); actions.addView(add,new LinearLayout.LayoutParams(0,dp(50),1));
        root.addView(actions);

        SeekBar seek=new SeekBar(this);
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));
        seek.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0x88FFFFFF));
        root.addView(seek,new LinearLayout.LayoutParams(-1,dp(28)));
        LinearLayout times=row();
        TextView elapsed=text("0:00",12,WHITE,false); TextView duration=text("--:--",12,WHITE,false);
        times.addView(elapsed,new LinearLayout.LayoutParams(0,-2,1)); times.addView(duration);
        root.addView(times);

        LinearLayout controls=row(); controls.setGravity(Gravity.CENTER);
        TextView shuffle=text("⤨",23,WHITE,true); shuffle.setGravity(Gravity.CENTER);
        TextView prev=text("|◀",23,WHITE,true); prev.setGravity(Gravity.CENTER); prev.setOnClickListener(v->playAt(Math.max(0,indexOfCurrent()-1)));
        TextView play=text(player!=null&&player.isPlaying()?"Ⅱ":"▶",31,Color.rgb(135,35,104),true);
        play.setGravity(Gravity.CENTER); play.setBackground(shape(Color.WHITE,40));
        TextView next=text("▶|",23,WHITE,true); next.setGravity(Gravity.CENTER); next.setOnClickListener(v->playAt(Math.min(songs.size()-1,indexOfCurrent()+1)));
        TextView repeat=text("↻",23,WHITE,true); repeat.setGravity(Gravity.CENTER);
        controls.addView(shuffle,new LinearLayout.LayoutParams(0,dp(58),1));
        controls.addView(prev,new LinearLayout.LayoutParams(0,dp(58),1));
        controls.addView(play,new LinearLayout.LayoutParams(dp(62),dp(62)));
        controls.addView(next,new LinearLayout.LayoutParams(0,dp(58),1));
        controls.addView(repeat,new LinearLayout.LayoutParams(0,dp(58),1));
        play.setOnClickListener(v->{togglePlayback();play.setText(player!=null&&player.isPlaying()?"Ⅱ":"▶");});
        root.addView(controls);

        LinearLayout bottom=row(); bottom.setGravity(Gravity.CENTER);
        String[] labels={"Lyrics","♡ Favourite","↓ Download","••• More"};
        for(String label:labels){TextView t=text(label,11,WHITE,false);t.setGravity(Gravity.CENTER);t.setPadding(dp(3),dp(15),dp(3),dp(4));bottom.addView(t,new LinearLayout.LayoutParams(0,-2,1));}
        root.addView(bottom);

        setContentView(root);
        final Handler handler=new Handler(Looper.getMainLooper());
        Runnable updater=new Runnable(){public void run(){
            if(!isFullScreen)return;
            if(player!=null){try{if(player.getDuration()>0){seek.setMax(player.getDuration());seek.setProgress(player.getCurrentPosition());elapsed.setText(formatTime(player.getCurrentPosition()));duration.setText(formatTime(player.getDuration()));}}catch(Exception ignored){}}
            handler.postDelayed(this,500);
        }};
        handler.post(updater);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean user){if(user&&player!=null)elapsed.setText(formatTime(p));}
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){if(player!=null)try{player.seekTo(s.getProgress());}catch(Exception ignored){}}
        });
    }

    private String formatTime(int ms){int sec=Math.max(0,ms/1000);return String.format(Locale.ROOT,"%d:%02d",sec/60,sec%60);}
    private String readAll(InputStream in)throws Exception{ByteArrayOutputStream o=new ByteArrayOutputStream();byte[]b=new byte[8192];int n;while((n=in.read(b))!=-1)o.write(b,0,n);return o.toString("UTF-8");}
    private String pathEncode(String p)throws Exception{String[]a=p.split("/");StringBuilder b=new StringBuilder();for(int i=0;i<a.length;i++){if(i>0)b.append('/');b.append(URLEncoder.encode(a[i],"UTF-8").replace("+","%20"));}return b.toString();}

    @Override public void onBackPressed() {
        if(isFullScreen) buildLibrary();
        else super.onBackPressed();
    }
    @Override protected void onDestroy(){if(player!=null){player.release();player=null;}super.onDestroy();}
}
